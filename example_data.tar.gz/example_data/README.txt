This archives contains example input files for MendelScan variant scoring. The contents include:
variants.vcf	-	A variant file containing genotypes for three 1000 genomes samples
annotation.vep	-	Annotation for the variants in native VEP output format
family.ped	-	A pedigree file for the three samples, indicating two cases and one control
expression.tsv	-	A ranked gene expression file for the human retina

An example command to use these files might be:
java -jar MendelScan.jar score variants.vcf --vep-file annotation.vep --ped-file family.ped --gene-file expression.tsv --output-file mendelscan.tsv --output-vcf mendelscan.vcf

For comments or questions, please contact Dan Koboldt, dkoboldt (at) genome [dot] wustl [dot] edu

